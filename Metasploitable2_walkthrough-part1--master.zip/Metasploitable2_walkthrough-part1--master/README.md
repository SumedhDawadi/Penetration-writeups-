# Metasploitable2_walkthrough-part1-
Here is the walk through of few services on the vulnerable machine Metasploitable2. Services like FTP to MySql database is being exploited. 

