Link to the box: https://www.vulnhub.com/entry/kioptrix-level-1-1,22. 
Motive of the box is to get root access.
---------------------------------------------------------------------- 
1. Since I had problem with KIOPTRIX LEVEL 1 while booting, So had to change to Bridged-mode from NAT. Might be different in your case.
2. Since I have changed exploit name  47080.c to sumedh, make sure you check it.
3. Happy learning.
--------------------------------------------------------------------------------------------------------------------------------------
